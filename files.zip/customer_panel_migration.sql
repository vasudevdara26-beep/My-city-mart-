-- Run once in the Supabase SQL Editor (adds a city column for the city selector)
alter table public.shops add column if not exists city text;
create index if not exists shops_city_idx on public.shops (city);

-- Category values are stored lowercase and must match src/utils/constants.js ids:
-- clothing, shoes, electronics, grocery, bakery, pharmacy, home, books

-- OPTIONAL sample data for testing. Replace the owner id with a real profiles.id.
-- insert into public.shops (owner_id, name, slug, category, city, address, pincode, latitude, longitude, status)
-- values
-- ('<YOUR-PROFILE-UUID>', 'Sharma General Store', 'sharma-general', 'grocery', 'Jaipur', 'MI Road', '302001', 26.9124, 75.7873, 'approved'),
-- ('<YOUR-PROFILE-UUID>', 'Step Up Footwear', 'step-up', 'shoes', 'Jaipur', 'C-Scheme', '302001', 26.9140, 75.7990, 'approved');
--
-- insert into public.products (shop_id, name, price, mrp, unit, stock_quantity)
-- select id, 'Basmati Rice', 120, 140, 'kg', 50 from public.shops where slug = 'sharma-general';
