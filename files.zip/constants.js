export const CITIES = ['Jaipur', 'Delhi', 'Mumbai', 'Bengaluru', 'Pune', 'Ahmedabad'];

// `id` must match the lowercase value stored in shops.category
export const CATEGORIES = [
  { id: 'clothing', label: 'Clothing', icon: '👕' },
  { id: 'shoes', label: 'Shoes', icon: '👟' },
  { id: 'electronics', label: 'Electronics', icon: '📱' },
  { id: 'grocery', label: 'Grocery', icon: '🛒' },
  { id: 'bakery', label: 'Bakery', icon: '🍰' },
  { id: 'pharmacy', label: 'Pharmacy', icon: '💊' },
  { id: 'home', label: 'Home', icon: '🛋️' },
  { id: 'books', label: 'Books', icon: '📚' },
];

export const getCategoryMeta = (id) =>
  CATEGORIES.find((c) => c.id === id) || { id, label: id || 'Other', icon: '🏪' };
