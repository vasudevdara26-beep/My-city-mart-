import { useEffect, useState } from 'react';
import Header from '../../components/common/Header';
import CategoryList from '../../components/customer/CategoryList';
import ShopCard from '../../components/customer/ShopCard';
import { fetchShops } from '../../services/shopService';
import { CITIES, getCategoryMeta } from '../../utils/constants';

const CITY_KEY = 'citymarket_city';

function readSavedCity() {
  try {
    return localStorage.getItem(CITY_KEY) || CITIES[0];
  } catch {
    return CITIES[0];
  }
}

function SkeletonCard() {
  return (
    <div className="animate-pulse overflow-hidden rounded-2xl border border-gray-100 bg-white">
      <div className="h-36 bg-gray-200" />
      <div className="space-y-2 p-4">
        <div className="h-4 w-2/3 rounded bg-gray-200" />
        <div className="h-3 w-1/3 rounded bg-gray-200" />
        <div className="h-3 w-full rounded bg-gray-200" />
      </div>
    </div>
  );
}

export default function Home() {
  const [city, setCity] = useState(readSavedCity);
  const [category, setCategory] = useState(null);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');

  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Debounce search so we don't query on every keystroke
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 350);
    return () => clearTimeout(t);
  }, [search]);

  const handleCityChange = (value) => {
    setCity(value);
    try {
      localStorage.setItem(CITY_KEY, value);
    } catch {
      /* ignore */
    }
  };

  // Fetch shops whenever a filter changes
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');

    fetchShops({ city, category, search: debouncedSearch })
      .then((data) => !cancelled && setShops(data))
      .catch((err) => !cancelled && setError(err.message || 'Could not load shops'))
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true; // ignore stale responses
    };
  }, [city, category, debouncedSearch]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header city={city} onCityChange={handleCityChange} search={search} onSearchChange={setSearch} />

      <main className="mx-auto max-w-6xl space-y-8 px-4 py-6">
        <CategoryList selected={category} onSelect={setCategory} />

        <section aria-label="Nearby shops">
          <div className="mb-3 flex items-end justify-between">
            <h2 className="text-lg font-bold text-gray-900">
              {category ? `${getCategoryMeta(category).label} shops` : 'Shops'} in {city}
            </h2>
            {!loading && !error && (
              <span className="text-sm text-gray-500">{shops.length} found</span>
            )}
          </div>

          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              {error}
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <SkeletonCard key={i} />
              ))}
            </div>
          ) : !error && shops.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center">
              <div className="text-4xl" aria-hidden>🏪</div>
              <p className="mt-2 font-semibold text-gray-800">No shops found</p>
              <p className="text-sm text-gray-500">Try another category, city or search term.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {shops.map((shop) => (
                <ShopCard key={shop.id} shop={shop} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
