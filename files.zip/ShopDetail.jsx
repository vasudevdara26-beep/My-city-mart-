import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Header from '../../components/common/Header';
import ProductCard from '../../components/customer/ProductCard';
import { useCart } from '../../context/CartContext';
import { fetchShopById } from '../../services/shopService';
import { fetchProductsByShop } from '../../services/productService';
import { getCategoryMeta } from '../../utils/constants';
import { formatCurrency } from '../../utils/formatCurrency';

export default function ShopDetail() {
  const { shopId } = useParams();
  const { addItem, decrementItem, getQuantity, totalItems, subtotal } = useCart();

  const [shop, setShop] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');

    Promise.all([fetchShopById(shopId), fetchProductsByShop(shopId)])
      .then(([shopData, productData]) => {
        if (cancelled) return;
        setShop(shopData);
        setProducts(productData);
      })
      .catch((err) => !cancelled && setError(err.message || 'Could not load this shop'))
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true;
    };
  }, [shopId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="mx-auto max-w-6xl animate-pulse space-y-4 px-4 py-6">
          <div className="h-44 rounded-2xl bg-gray-200" />
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-60 rounded-2xl bg-gray-200" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !shop) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="mx-auto max-w-md px-4 py-20 text-center">
          <div className="text-5xl" aria-hidden>😕</div>
          <p className="mt-3 font-semibold text-gray-800">{error || 'Shop not found'}</p>
          <Link to="/" className="mt-4 inline-block rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white">
            Back to shops
          </Link>
        </div>
      </div>
    );
  }

  const category = getCategoryMeta(shop.category);
  const banner = shop.banner_url || shop.logo_url;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <Header />

      <main className="mx-auto max-w-6xl space-y-6 px-4 py-6">
        <Link to="/" className="text-sm font-medium text-emerald-700 hover:underline">
          ← All shops
        </Link>

        {/* Shop banner */}
        <section className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
          <div className="h-40 bg-gradient-to-br from-emerald-100 to-teal-50 md:h-52">
            {banner ? (
              <img src={banner} alt={shop.name} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-6xl" aria-hidden>
                {category.icon}
              </div>
            )}
          </div>
          <div className="space-y-2 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">{shop.name}</h1>
              <span
                className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                  shop.is_open ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-200 text-gray-600'
                }`}
              >
                {shop.is_open ? 'Open now' : 'Closed'}
              </span>
            </div>
            {shop.description && <p className="text-sm text-gray-600">{shop.description}</p>}
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
              <span>{category.icon} {category.label}</span>
              <span>📍 {shop.address}</span>
              {shop.opening_time && shop.closing_time && (
                <span>🕒 {shop.opening_time.slice(0, 5)} – {shop.closing_time.slice(0, 5)}</span>
              )}
              <span>
                🚚 {Number(shop.delivery_fee) > 0 ? formatCurrency(shop.delivery_fee) : 'Free delivery'}
              </span>
              {Number(shop.min_order_amount) > 0 && (
                <span>Min order {formatCurrency(shop.min_order_amount)}</span>
              )}
            </div>
          </div>
        </section>

        {/* Products */}
        <section aria-label="Products">
          <h2 className="mb-3 text-lg font-bold text-gray-900">
            Products <span className="text-sm font-normal text-gray-500">({products.length})</span>
          </h2>

          {products.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center text-gray-500">
              This shop hasn't listed any products yet.
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  quantity={getQuantity(product.id)}
                  onAdd={() => addItem(product, shop)}
                  onIncrease={() => addItem(product, shop)}
                  onDecrease={() => decrementItem(product.id)}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Sticky cart bar */}
      {totalItems > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-gray-200 bg-white p-3 shadow-lg">
          <Link
            to="/cart"
            className="mx-auto flex max-w-6xl items-center justify-between rounded-xl bg-emerald-600 px-5 py-3 font-semibold text-white hover:bg-emerald-700"
          >
            <span>{totalItems} item{totalItems > 1 && 's'} · {formatCurrency(subtotal)}</span>
            <span>View Cart →</span>
          </Link>
        </div>
      )}
    </div>
  );
}
