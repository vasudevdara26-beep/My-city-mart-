import { Link } from 'react-router-dom';
import { getCategoryMeta } from '../../utils/constants';
import { formatCurrency } from '../../utils/formatCurrency';

export default function ShopCard({ shop }) {
  const category = getCategoryMeta(shop.category);
  const image = shop.banner_url || shop.logo_url;

  return (
    <Link
      to={`/shop/${shop.id}`}
      className="group block overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative h-36 overflow-hidden bg-gradient-to-br from-emerald-100 to-teal-50">
        {image ? (
          <img
            src={image}
            alt={shop.name}
            loading="lazy"
            className="h-full w-full object-cover transition group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-5xl" aria-hidden>
            {category.icon}
          </div>
        )}
        <span
          className={`absolute right-2 top-2 rounded-full px-2 py-0.5 text-xs font-semibold ${
            shop.is_open ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-100'
          }`}
        >
          {shop.is_open ? 'Open' : 'Closed'}
        </span>
      </div>

      <div className="space-y-1 p-4">
        <h3 className="truncate font-semibold text-gray-900">{shop.name}</h3>
        <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-700">
          {category.icon} {category.label}
        </span>
        <p className="truncate text-sm text-gray-500">📍 {shop.address}</p>
        <p className="text-xs text-gray-500">
          {Number(shop.delivery_fee) > 0
            ? `Delivery ${formatCurrency(shop.delivery_fee)}`
            : 'Free delivery'}
          {Number(shop.min_order_amount) > 0 &&
            ` · Min order ${formatCurrency(shop.min_order_amount)}`}
        </p>
      </div>
    </Link>
  );
}
