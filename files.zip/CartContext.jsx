import { createContext, useContext, useEffect, useMemo, useState } from 'react';

const CartContext = createContext(null);
const STORAGE_KEY = 'citymarket_cart';

function loadCart() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(loadCart);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* storage unavailable: cart still works in memory */
    }
  }, [items]);

  const value = useMemo(() => {
    const addItem = (product, shop) =>
      setItems((prev) => {
        const existing = prev.find((i) => i.productId === product.id);
        if (existing) {
          if (existing.quantity >= product.stock_quantity) return prev;
          return prev.map((i) =>
            i.productId === product.id ? { ...i, quantity: i.quantity + 1 } : i
          );
        }
        return [
          ...prev,
          {
            productId: product.id,
            shopId: shop.id,
            shopName: shop.name,
            name: product.name,
            price: Number(product.price),
            unit: product.unit,
            image: product.image_urls?.[0] || null,
            stock: product.stock_quantity,
            quantity: 1,
          },
        ];
      });

    const decrementItem = (productId) =>
      setItems((prev) =>
        prev
          .map((i) => (i.productId === productId ? { ...i, quantity: i.quantity - 1 } : i))
          .filter((i) => i.quantity > 0)
      );

    const removeItem = (productId) =>
      setItems((prev) => prev.filter((i) => i.productId !== productId));

    const clearCart = () => setItems([]);

    const getQuantity = (productId) =>
      items.find((i) => i.productId === productId)?.quantity || 0;

    return {
      items,
      addItem,
      decrementItem,
      removeItem,
      clearCart,
      getQuantity,
      totalItems: items.reduce((sum, i) => sum + i.quantity, 0),
      subtotal: items.reduce((sum, i) => sum + i.price * i.quantity, 0),
    };
  }, [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>');
  return ctx;
}
