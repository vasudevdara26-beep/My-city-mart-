import { supabase } from '../lib/supabaseClient';

export async function fetchProductsByShop(shopId) {
  const { data, error } = await supabase
    .from('products')
    .select('id, shop_id, name, description, price, mrp, unit, stock_quantity, image_urls')
    .eq('shop_id', shopId)
    .eq('is_available', true)
    .order('name');

  if (error) throw error;
  return data;
}
