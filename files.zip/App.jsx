import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import Home from './pages/customer/Home';
import ShopDetail from './pages/customer/ShopDetail';

export default function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop/:shopId" element={<ShopDetail />} />
          {/* Next step: <Route path="/cart" element={<Cart />} /> */}
        </Routes>
      </BrowserRouter>
    </CartProvider>
  );
}
